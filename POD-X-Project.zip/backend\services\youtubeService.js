const youtubedl = require('youtube-dl-exec');
const fetch = require('node-fetch');

// Modes: 'cobalt' (API), 'ytdlp' (Binary), 'mock' (Fallback)
let currentMode = process.env.YOUTUBE_MODE || 'cobalt';

const MOCK_DATA = {
    title: 'Test Audio Stream',
    channel: 'POD-X Demo',
    duration: 372,
    thumbnail: 'https://via.placeholder.com/300x300/6B46C1/FFFFFF?text=POD-X',
    streamUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    videoId: 'mock-id'
};

/**
 * Extract YouTube metadata and stream URL
 */
async function extractYouTubeData(url) {
    console.log(`[YouTube Service] Extracting: ${url} (Mode: ${currentMode})`);

    try {
        if (currentMode === 'cobalt') {
            return await extractWithCobalt(url);
        } else if (currentMode === 'ytdlp') {
            return await extractWithYtDlp(url);
        } else {
            return getMockData(url);
        }
    } catch (error) {
        console.error(`[YouTube Service] Error in ${currentMode} mode:`, error.message);

        // Fallback Logic
        if (currentMode === 'cobalt') {
            console.warn('[YouTube Service] Cobalt failed, trying yt-dlp');
            // Try yt-dlp only if local (check for binary existence implicitly by trying)
            try {
                return await extractWithYtDlp(url);
            } catch (e) {
                console.warn('[YouTube Service] yt-dlp fallback also failed');
            }
        }

        // Final fallback to mock if everything fails
        console.warn('[YouTube Service] Switching to Mock mode');
        return getMockData(url);
    }
}

/**
 * Extract using Cobalt API (Primary Method)
 * Returns direct MP3 stream URL
 */
async function extractWithCobalt(url) {
    try {
        console.log('[Cobalt] Attempting extraction...');
        const response = await fetch('https://api.cobalt.tools/api/json', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                url: url,
                isAudioOnly: true,
                filenamePattern: 'basic'
            }),
        });

        if (!response.ok) {
            throw new Error(`Cobalt API returned ${response.status}`);
        }

        const data = await response.json();

        if (!data.url) {
            throw new Error('Cobalt extraction failed - no URL returned');
        }

        // Validate URL - sometimes Cobalt returns pickle/dubious URLs, ensure it's http
        if (!data.url.startsWith('http')) {
            throw new Error('Invalid URL returned by Cobalt');
        }

        const videoId = extractVideoId(url);

        return {
            title: data.filename || `YouTube Video ${videoId}`, // Cobalt often returns filename
            channel: 'YouTube',
            duration: 0, // Cobalt doesn't always give duration
            thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
            streamUrl: data.url,
            videoId: videoId,
            description: '',
            type: 'audio',
            format: 'mp3' // Signal that this is an MP3
        };
    } catch (error) {
        console.error('[Cobalt] Extraction failed:', error.message);
        throw error;
    }
}

/**
 * Extract using yt-dlp (Secondary Method - Localhost only usually)
 */
async function extractWithYtDlp(url) {
    try {
        console.log('[yt-dlp] Attempting extraction with robust filters...');
        const result = await youtubedl(url, {
            dumpSingleJson: true,
            noWarnings: true,
            noCallHome: true,
            noCheckCertificate: true,
            preferFreeFormats: true,
            youtubeSkipDashManifest: true, // CRITICAL: Skip DASH manifests
            referer: 'https://www.youtube.com',
            addHeader: ['User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36']
        });

        // Find best audio-only format with HTTP protocol (not HLS/DASH)
        // This ensures direct playback compatibility
        const audioFormat = result.formats?.reverse().find(f =>
            f.acodec !== 'none' &&
            f.vcodec === 'none' &&
            (f.protocol === 'http' || f.protocol === 'https' || f.protocol === 'https+https') &&
            !f.url.includes('.m3u8') &&
            !f.url.includes('manifest')
        );

        const streamUrl = audioFormat?.url || result.url;

        if (!streamUrl) {
            throw new Error('No compatible audio stream found');
        }

        console.log('[yt-dlp] Success. Format:', audioFormat?.format_id, 'Protocol:', audioFormat?.protocol);

        return {
            title: result.title || 'Unknown Title',
            channel: result.uploader || 'Unknown Channel',
            duration: result.duration || 0,
            thumbnail: result.thumbnail || '',
            streamUrl: streamUrl,
            videoId: result.id,
            description: result.description ? result.description.substring(0, 200) : '',
            type: 'audio',
            format: audioFormat?.ext || 'mp3'
        };
    } catch (error) {
        console.error('[yt-dlp] Extraction failed:', error.message);
        throw error;
    }
}

/**
 * Mock mode for development
 */
function getMockData(url) {
    console.log('[Mock Mode] Returning test data');
    const videoId = extractVideoId(url) || 'mock-id';
    return {
        ...MOCK_DATA,
        title: `Mock Video ${videoId}`,
        videoId: videoId,
        thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
    };
}

/**
 * Extract video ID from URL
 */
function extractVideoId(url) {
    const patterns = [
        /(?:v=|\/)([\w-]{11})/,
        /youtu\.be\/([\w-]{11})/,
        /embed\/([\w-]{11})/
    ];

    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) return match[1];
    }

    return null;
}

module.exports = {
    extractYouTubeData
};
